/*************** VOCE DEVE IMPLEMENTAR AS FUNCOES AQUI ***************/
/* 
 * Esqueleto para sua implementacao dos algoritmos de ordenacao
 * 
 */

#include <stdlib.h>
#include <stdio.h>
#include "ordenacao.h"

int partition(int c, int f, int v[]) {
	return 0;
}

void quickSort(int c, int f, int v[]) {
}

void bubbleSort(int n, int v[]) {
}

void selectionSort(int n, int v[]) {
}

void merge(int c, int m, int f, int v[]) {
} 

void mergeSort(int c, int f, int v[]) {
}

void insertionSort(int n, int v[]) {
} 
